package com.jvms.i18neditor;

/**
 * An enum describing file structures.
 * 
 * @author Jacob van Mourik
 */
public enum FileStructure {
	Flat, 
	Nested
}
